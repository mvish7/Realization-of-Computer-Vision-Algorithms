#include <iostream>
#include <math.h>

#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>

#include "Segmentation.h"
#include "Filter.h"

////////////////////////////////////////////////////////////////////////////////////
// constructor and destructor
////////////////////////////////////////////////////////////////////////////////////
Segmentation::Segmentation(){}

Segmentation::~Segmentation(){}

////////////////////////////////////////////////////////////////////////////////////
// Cut template image from input and save as file
////////////////////////////////////////////////////////////////////////////////////
void Segmentation::cutAndSave(const cv::Mat &input, cv::Point origin, cv::Size size, const cv::string &filename)
{
    // define rectangle from origin and size
    cv::Rect rect(origin, size);

    // cut the rectangle and create template
    cv::Mat templ = input(rect);

    // save template to file
    cv::imwrite(filename, templ);
}

////////////////////////////////////////////////////////////////////////////////////
// Find brightest pixel and return its coordinates as Point
////////////////////////////////////////////////////////////////////////////////////
cv::Point Segmentation::findMaximum(const cv::Mat &input)
{
    // declare array to hold the indizes
    int maxIndex[2];

    // find the maximum
    cv::minMaxIdx(input, 0, 0, 0, maxIndex);

    // create Point and return
    return cv::Point(maxIndex[1], maxIndex[0]);
}

////////////////////////////////////////////////////////////////////////////////////
// Add a black rectangle to an image
////////////////////////////////////////////////////////////////////////////////////
void Segmentation::drawRect(const cv::Mat &input, cv::Point origin, cv::Size size, cv::Mat &output)
{
    // define rectangle from origin and size
    cv::Rect rect(origin, size);

    // copy input image to output
    output = input.clone();

    // draw the rectangle
    cv::rectangle(output, rect, 0, 2);
}

///////////////////////////////////////////////////////////////////////////////
// scale a Hough image for better displaying
///////////////////////////////////////////////////////////////////////////////
void Segmentation::scaleHoughImage(const cv::Mat &input, cv::Mat &output)
{
    // find max value
    double max;
    cv::minMaxLoc(input, 0, &max);

    // scale the image
    input.convertTo(output, CV_32F, 1.0f / max, 0);
}


////////////////////////////////////////////////////////////////////////////////////
// Compute Hough Transformation for cirlces with fixed radius
////////////////////////////////////////////////////////////////////////////////////

// cellStep: accumulator cell size
void Segmentation::houghCircle(const cv::Mat &input, cv::Mat &output,
                               const int radius, const float cellStep,
                               const float phiStep)
{
    output.release();


    ///////////////////////////////
    // insert your code here ... 
    // 
    // input image: uchar (black and white)
    //
    // output image: 32 bit integer
    //          output = cv::Mat::zeros(???, ???, CV_32S);
    //////////////////////////////  

    output = cv::Mat::zeros(1, 1 , CV_32S); // you have to replace this line

}


////////////////////////////////////////////////////////////////////////////////////
// Find circles in an image
// 
// every circle has to be added to the list, e.g.:
//
//      CircleItem newItem; // create a new list item
//      newItem.x = x; // set variables of the list item
//      newItem.y = y;
//      newItem.r = r;
//      list->push_back(newItem); // add the item to the list
//
// accessing the list of circles: see section 'show list of found cirles' in
//                               the following function
////////////////////////////////////////////////////////////////////////////////////

void Segmentation::findCircles(const cv::Mat &input, std::vector<CircleItem> *list, const int radiusMin,
                               const int radiusMax, const float cellStep,
                               const float phiStep)
{
    list->clear();

    ////////////////////////////////////////////////////////////////////////////////////
    // for every radius:
    // - Hough Circle Transformation
    // - find maxima
    // - if the maxima represents a circle center add it to the list
    //
    // note: finding more than one maximum can be done by removing the already found
    //       maxima from the Hough transformed image (like it was done in exercise 5b)
    //
    // note: a maximum in a Hough transformed image has a certain value
    //       this value can be used to decide if the the maximum represents a circle
    //       (e.g. you can establish a valueMin and if the value is below valueMin
    //        stop searching for further circle centers in the image)
    ////////////////////////////////////////////////////////////////////////////////////
    


    ////////////////////////////////////////////////////////////////////////////////////
    // insert your code here ... 
    //
    // note: 'insert here' does not mean that you are not allowed to write
    //        additional functions; please do so, if you need them
    ////////////////////////////////////////////////////////////////////////////////////  



    // show list of found cirles
    std::cout << "       " << list->size() << " cirles found:\n";
    for (int i = 0; i < list->size(); ++i)
    {
        CircleItem item = list->at(i);
        std::cout << "\t#" << (i + 1) << "\tcenter: (" << item.x << "," << item.y << "), \tradius=" << item.r << "\n";
    }

}

cv::Point Segmentation::findAndRemoveMaximum(cv::Mat &image, int *value, const int radius, const float cellStep)
{
    cv::Point point;
    double min = 0.0;
    double max = 0.0;
    cv::minMaxLoc(image, &min, &max, nullptr, &point);
    *value = int(max);

    // remove Area around maximum
    cv::circle(image, point, 5, cv::Scalar(0, 0, 0), -1);

    // convert accumulator space coordinates to pixel coordinates of the image which was hough transformed
    point.x = round(float(point.x) * cellStep - radius);
    point.y = round(float(point.y) * cellStep - radius);

    return point;
}
